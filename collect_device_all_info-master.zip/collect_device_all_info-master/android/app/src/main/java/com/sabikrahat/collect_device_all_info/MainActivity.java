package com.sabikrahat.collect_device_all_info;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
